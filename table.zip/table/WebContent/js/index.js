/**
 * 
 */


/*******************列表头修改验证*************************/
function column_change(rank,describe){
	var tf = true;
	var tf_1 = true;
	
	if(rank!=""&/^[1-4]$/.test(rank)){      //等级框验证
		tf = true;
	}
	else{
		tf = false;
	}
	
	if(describe!=""&describe.length<150){      //描述框验证
		tf_1 = true;
	}
	else{
		tf = false;
	}
	
	if(tf&tf_1){
		return true;
	}else{
		return false;
	}
	
}




/*************************行表头修改验证********************************/

function row_table_change(academic_degree,start_age,end_age){
	var tf = true;
	var tf_1 = true;
	var tf_2 = true;
	
	if(academic_degree!=""){      //学位验证
		tf=true;
	}else{
		tf=false;
	}
	
	if(start_age==""){     //开始年龄，默认为0
		tf_1 = true;
		start_age = "0";
	}else if(/^[0-9]{1,3}$/.test(start_age)){
		tf_1 = true;
	}else{
		tf_1 = false;
	}
	
	
	if(end_age==""){        //结束年龄，默认为以上
		tf_2 = true;
		end_age="以上";
	}else if(/^[0-9]{1,3}$/.test(end_age)&end_age>=start_age){
		tf_2 = true;
	}else{
		tf_2 = false;
	}
	
	
	if(tf&tf_1&tf_2){
		return true;
	}else{
		return false;
	}
	
}


/***************分数验证*************************/
function grade_change(start_grade,end_grade){
	
	var tf_1 = true;
	var tf_2 = true;
	
	if(start_grade==""){     //开始成绩，默认为0
		tf_1 = true;
		start_grade = 0;
	}else if(start_grade>=0&start_grade<=100){
		tf_1 = true;
	}else{
		tf_1 = false;
	}
	
	
	if(end_grade==""){        //结束成绩，默认为100
		tf_2 = true;
		end_grade=100;
	}else if(end_grade>=0&end_grade<=100&end_grade>=start_grade){
		tf_2 = true;
	}else{
		tf_2 = false;
	}
	
	
	if(tf_1&tf_2){
		return true;
	}else{
		return false;
	}
	
}



/***********************表头省略函数*************************************/
function ellipsis(str){
	if(str.length>5){
		str = str.substring(0,4)+"...";
	}
	return str;
}



/*********************具体修改dom的函数************************/

$(function(){    //修改相关
	$("#test_table .table tbody tr td,table thead tr th").mouseover(function(){    //鼠标效果
		$(this).addClass("active");
		$(this).siblings().removeClass("active");
		$(this).parent().siblings().children().removeClass("active");
		$(this).parent().parent().siblings().children().children().removeClass("active");
	});
	
	
	{      //行表头修改
		var $html = $("#input_row_header_table").html();
	$("#test_table .table tbody tr td:contains('/')").dblclick(function(){
		var $table_row_head = $(this);   //行表头
		$.confirm({
		    title: '修改',
		    content: "<div id='row_header'>"+$html+"</div>",
		    confirm: function(){      //保存的回调函数
		    	var academic_degree = $("#row_header select:eq(0)").val();   //学位
		    	var start_age = $("#row_header input:eq(0)").val();    //开始年龄
		    	var end_age = $("#row_header input:eq(1)").val();     //结束年龄

		    	
		    	if(row_table_change(academic_degree,start_age,end_age)){
		    		
		    		if(start_age==""){     //开始年龄，默认为0
		    			tf_1 = true;
		    			start_age = "0";
		    		}else if(/^[0-9]{1,3}$/.test(start_age)){
		    			tf_1 = true;
		    		}else{
		    			tf_1 = false;
		    		}
		    		
		    		
		    		if(end_age==""){        //结束年龄，默认为以上
		    			tf_2 = true;
		    			start_age = start_age+"岁";
		    			end_age="以上";
		    		}else if(/^[0-9]{1,3}$/.test(end_age)&end_age>=start_age){
		    			end_age = end_age+"岁";
		    			start_age = start_age+"~";
		    			tf_2 = true;
		    		}else{
		    			tf_2 = false;
		    		}
		    		
		    		
		    		$table_row_head.html(academic_degree+"/"+start_age+end_age);
		    	}else{
		    		$.alert('修改失败，请检查输入是否正确！');
		    	}
		    	
		    },
		    cancel: function(){      //取消的回调函数
		      
		    }
		});
	});
	}
	
	
	
	{      //列表头修改
		var $html_1 = $("#input_column_header_table").html();
	$("#test_table .table thead tr th:contains('/')").dblclick(function(){
		var $table_column_head = $(this);   //列表头
		$.confirm({
		    title: '修改',
		    content: "<div id='column_header'>"+$html_1+"</div>",
		    confirm: function(){      //保存的回调函数
		    	var rank = $("#column_header input:eq(0)").val();   //等级
		    	var describe = $("#column_header textarea:eq(0)").val();   //描述
		    	
		    	if(column_change(rank,describe) ){
		    		$table_column_head.children().eq(0).html(rank);	
		    		$table_column_head.children().eq(1).html(ellipsis(describe));
		    		$table_column_head.children().eq(2).html(describe);
		    	}else{
		    		$.alert('修改失败，请检查输入是否正确！');
		    	}    	
		    },
		    cancel: function(){      //取消的回调函数
		      
		    }
		});
	});
	}
	
	
	{      //表单元修改
		var $html_2 = $("#input_unit_table").html();
	$("#test_table .table tbody tr td:contains('/')").siblings().dblclick(function(){
		var unit_table = $(this);    //单元格
		$.confirm({
		    title: '修改',
		    content: "<div id='unit'>"+$html_2+"</div>",
		    confirm: function(){      //保存的回调函数
		    	var start_grade = $("#unit input:eq(0)").val();    //开始分数
		    	var end_grade = $("#unit input:eq(1)").val();     //结束分数
		    	
		    	if(grade_change(start_grade,end_grade)){
		    		
		    		
		    		if(start_grade==""){     //开始成绩，默认为0
		    			tf_1 = true;
		    			start_grade = 0;
		    		}else if(start_grade>=0&start_grade<=100){
		    			tf_1 = true;
		    		}else{
		    			tf_1 = false;
		    		}
		    		
		    		
		    		if(end_grade==""){        //结束成绩，默认为100
		    			tf_2 = true;
		    			end_grade=100;
		    		}else if(end_grade>=0&end_grade<=100&end_grade>=start_grade){
		    			tf_2 = true;
		    		}else{
		    			tf_2 = false;
		    		}
		    		
		    	unit_table.html(start_grade+"~"+end_grade);
		    	}else{
		    		$.alert('修改失败，请检查输入是否正确！');
		    	}
		    	
		    },
		    cancel: function(){      //取消的回调函数
		      
		    }
		});
	});
	}
	
});



/******************提示工具*********************/
$(function(){
	{            //初始化提示工具
	var tip0 = $("#test_table .table thead tr th:contains('/') span:contains('...')")[0];
	var tip1 = $("#test_table .table thead tr th:contains('/') span:contains('...')")[1];
	var tip2 = $("#test_table .table thead tr th:contains('/') span:contains('...')")[2];
	var tip3 = $("#test_table .table thead tr th:contains('/') span:contains('...')")[3];
	
	var tip_val_0 = $("#test_table .table thead tr th:contains('/') span:contains('...')").eq(0).next().html();
	var tip_val_1 = $("#test_table .table thead tr th:contains('/') span:contains('...')").eq(1).next().html();
	var tip_val_2 = $("#test_table .table thead tr th:contains('/') span:contains('...')").eq(2).next().html();
	var tip_val_3 = $("#test_table .table thead tr th:contains('/') span:contains('...')").eq(3).next().html();
	
	tip0.title=tip_val_0;
	tip1.title=tip_val_1;
	tip2.title=tip_val_2;
	tip3.title=tip_val_3;
	}
	
	$("#test_table .table thead tr th:contains('/') span:contains('...')").mouseover(function () {     //重置提示内容
		$(this)[0].title = $(this).next().html();		
		});

});




/*********************产生json数据****************************/

function table_json(){
	/*var json = [ [{}               ,{"rank":rank,"describe":describe},{"rank":rank,"describe":describe},{"rank":rank,"describe":describe},{"rank":rank,"describe":describe}],
			     [{"academic_degree":academic_degree,"start_age":start_age,"end_age":end_age},{"start_grade":start_grade,"end_grade":end_grade},{"start_grade":start_grade,"end_grade":end_grade},{"start_grade":start_grade,"end_grade":end_grade},{"start_grade":start_grade,"end_grade":end_grade}],
			     [{"academic_degree":academic_degree,"start_age":start_age,"end_age":end_age},{"start_grade":start_grade,"end_grade":end_grade},{"start_grade":start_grade,"end_grade":end_grade},{"start_grade":start_grade,"end_grade":end_grade},{"start_grade":start_grade,"end_grade":end_grade}],
			     [{"academic_degree":academic_degree,"start_age":start_age,"end_age":end_age},{"start_grade":start_grade,"end_grade":end_grade},{"start_grade":start_grade,"end_grade":end_grade},{"start_grade":start_grade,"end_grade":end_grade},{"start_grade":start_grade,"end_grade":end_grade}]
	           ];*/
	
	
	var json;
	
	for(var i=0;i<4;i++){    //i为行j为列
		if(i=0){
		for(var j=0;j<5;j++){
			json[i][j].rank=$("#test_table .table thead tr th:eq("+j+") span:eq(0)").html();
			json[i][j].describe=$("#test_table .table thead tr th:eq("+j+") span:eq(2)").html();
		}
		}
		else{
			if(j=0){
				json[i][j].academic_degree=$("#test_table .table tbody tr:eq("+i+") td:contains('/')").html().substring(0,1);
				json[i][j].age=$("#test_table .table tbody tr:eq("+i+") td:contains('/')").html().split("/")[1];
			}else{
				json[i][j].grade=$("#test_table .table tbody tr td:eq("+j+")").html();
			}
		}
	}
	
	
	return json;
	
}


